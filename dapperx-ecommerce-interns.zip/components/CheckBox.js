import React, { useState } from 'react'

const CheckBox = ({name}) => {
    
  return (
    <div>
      <input type='checkbox'/> {name}
    </div>
  )
}

export default CheckBox
