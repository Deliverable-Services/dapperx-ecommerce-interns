import React from 'react'

const Footer = () => {
  return (
    <div>
      This is footer section
    </div>
  )
}

export default Footer
