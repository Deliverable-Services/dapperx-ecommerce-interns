import React from 'react'

const Collection = () => {
  return (
    <div>
      This is our collection page and all our latest collection will be shown here
    </div>
  )
}

export default Collection
