import React from 'react'

const Deals = () => {
  return (
    <div>
      This is deals page all our deals will be shown here
    </div>
  )
}

export default Deals
