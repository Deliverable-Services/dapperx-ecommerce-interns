/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "__barrel_optimize__?names=CgProfile!=!./node_modules/react-icons/cg/index.mjs":
/*!*************************************************************************************!*\
  !*** __barrel_optimize__?names=CgProfile!=!./node_modules/react-icons/cg/index.mjs ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_cg_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/react-icons/cg/index.mjs */ "./node_modules/react-icons/cg/index.mjs");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_cg_index_mjs__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_cg_index_mjs__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "__barrel_optimize__?names=CiHeart!=!./node_modules/react-icons/ci/index.mjs":
/*!***********************************************************************************!*\
  !*** __barrel_optimize__?names=CiHeart!=!./node_modules/react-icons/ci/index.mjs ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_ci_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/react-icons/ci/index.mjs */ "./node_modules/react-icons/ci/index.mjs");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_ci_index_mjs__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_ci_index_mjs__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "__barrel_optimize__?names=CiSearch!=!./node_modules/react-icons/ci/index.mjs":
/*!************************************************************************************!*\
  !*** __barrel_optimize__?names=CiSearch!=!./node_modules/react-icons/ci/index.mjs ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_ci_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/react-icons/ci/index.mjs */ "./node_modules/react-icons/ci/index.mjs");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_ci_index_mjs__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_ci_index_mjs__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "__barrel_optimize__?names=IoBagHandle!=!./node_modules/react-icons/io5/index.mjs":
/*!****************************************************************************************!*\
  !*** __barrel_optimize__?names=IoBagHandle!=!./node_modules/react-icons/io5/index.mjs ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_io5_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/react-icons/io5/index.mjs */ "./node_modules/react-icons/io5/index.mjs");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_io5_index_mjs__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => C_Users_Lenovo_Desktop_Work_projects_dapperx_ecommerce_interns_node_modules_react_icons_io5_index_mjs__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "./components/Footer.jsx":
/*!*******************************!*\
  !*** ./components/Footer.jsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Footer = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: \"This is footer section\"\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Footer.jsx\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0Zvb3Rlci5qc3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQXlCO0FBRXpCLE1BQU1DLFNBQVM7SUFDYixxQkFDRSw4REFBQ0M7a0JBQUk7Ozs7OztBQUlUO0FBRUEsaUVBQWVELE1BQU1BLEVBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9tYXNjdWxpbmUvLi9jb21wb25lbnRzL0Zvb3Rlci5qc3g/Mzg5NSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXHJcblxyXG5jb25zdCBGb290ZXIgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIFRoaXMgaXMgZm9vdGVyIHNlY3Rpb25cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRm9vdGVyXHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIkZvb3RlciIsImRpdiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/Footer.jsx\n");

/***/ }),

/***/ "./components/Navbar.jsx":
/*!*******************************!*\
  !*** ./components/Navbar.jsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _barrel_optimize_names_CiSearch_react_icons_ci__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=CiSearch!=!react-icons/ci */ \"__barrel_optimize__?names=CiSearch!=!./node_modules/react-icons/ci/index.mjs\");\n/* harmony import */ var _barrel_optimize_names_CiHeart_react_icons_ci__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! __barrel_optimize__?names=CiHeart!=!react-icons/ci */ \"__barrel_optimize__?names=CiHeart!=!./node_modules/react-icons/ci/index.mjs\");\n/* harmony import */ var _barrel_optimize_names_IoBagHandle_react_icons_io5__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! __barrel_optimize__?names=IoBagHandle!=!react-icons/io5 */ \"__barrel_optimize__?names=IoBagHandle!=!./node_modules/react-icons/io5/index.mjs\");\n/* harmony import */ var _barrel_optimize_names_CgProfile_react_icons_cg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! __barrel_optimize__?names=CgProfile!=!react-icons/cg */ \"__barrel_optimize__?names=CgProfile!=!./node_modules/react-icons/cg/index.mjs\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/image */ \"./node_modules/next/image.js\");\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\n\n\n\n\nconst Navbar = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"flex flex-row w-12/12 gap-16 items-center justify-between mr-14 ml-14 bg-[#EDEEF1]\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \" flex flex-row gap-8 items-center justify-center font-semibold\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"bg-black flex text-white rounded-full w-[40px] h-[40px] items-center justify-center text-xl \",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                            href: \"/\",\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_CiSearch_react_icons_ci__WEBPACK_IMPORTED_MODULE_4__.CiSearch, {\n                                className: \"size-6\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                                lineNumber: 13,\n                                columnNumber: 26\n                            }, undefined)\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                            lineNumber: 13,\n                            columnNumber: 9\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                        lineNumber: 12,\n                        columnNumber: 9\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                        href: \"/\",\n                        children: \"HOME\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                        lineNumber: 15,\n                        columnNumber: 9\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                        href: \"/collections\",\n                        children: \"COLLECTIONS\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                        lineNumber: 16,\n                        columnNumber: 9\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                        href: \"/deals\",\n                        children: \"DEALS\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                        lineNumber: 17,\n                        columnNumber: 9\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                lineNumber: 11,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"my-4\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {\n                    className: \"flex rounded-xl\",\n                    src: \"/masculine.png\",\n                    width: 150,\n                    height: 30,\n                    alt: \"logo\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                    lineNumber: 21,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                lineNumber: 20,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"flex flex-row gap-8 items-center justify-center font-semibold \",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                        href: \"/blogs\",\n                        children: \"BLOGS\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                        lineNumber: 31,\n                        columnNumber: 9\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                        href: \"/liked-products\",\n                        className: \"bg-black flex text-white rounded-full w-[40px] h-[40px] items-center justify-center text-xl \",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_CiHeart_react_icons_ci__WEBPACK_IMPORTED_MODULE_5__.CiHeart, {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                            lineNumber: 32,\n                            columnNumber: 145\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                        lineNumber: 32,\n                        columnNumber: 9\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                        href: \"/cart\",\n                        className: \"bg-black flex text-white rounded-full w-[40px] h-[40px] items-center justify-center text-xl \",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_IoBagHandle_react_icons_io5__WEBPACK_IMPORTED_MODULE_6__.IoBagHandle, {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                            lineNumber: 33,\n                            columnNumber: 135\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                        lineNumber: 33,\n                        columnNumber: 9\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                        href: \"/profile\",\n                        className: \"bg-black flex text-white rounded-full w-[40px] h-[40px] items-center justify-center text-xl \",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_CgProfile_react_icons_cg__WEBPACK_IMPORTED_MODULE_7__.CgProfile, {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                            lineNumber: 34,\n                            columnNumber: 138\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                        lineNumber: 34,\n                        columnNumber: 9\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n                lineNumber: 30,\n                columnNumber: 7\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\components\\\\Navbar.jsx\",\n        lineNumber: 10,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL05hdmJhci5qc3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBeUI7QUFDaUI7QUFDRDtBQUNLO0FBQ0g7QUFDZDtBQUNFO0FBQy9CLE1BQU1PLFNBQVM7SUFDYixxQkFDRSw4REFBQ0M7UUFBSUMsV0FBVTs7MEJBQ2IsOERBQUNEO2dCQUFJQyxXQUFVOztrQ0FDYiw4REFBQ0Q7d0JBQUlDLFdBQVU7a0NBQ2YsNEVBQUNKLGtEQUFJQTs0QkFBQ0ssTUFBTTtzQ0FBSyw0RUFBQ1Qsb0ZBQVFBO2dDQUFDUSxXQUFVOzs7Ozs7Ozs7Ozs7Ozs7O2tDQUVyQyw4REFBQ0osa0RBQUlBO3dCQUFDSyxNQUFNO2tDQUFLOzs7Ozs7a0NBQ2pCLDhEQUFDTCxrREFBSUE7d0JBQUNLLE1BQU07a0NBQWdCOzs7Ozs7a0NBQzVCLDhEQUFDTCxrREFBSUE7d0JBQUNLLE1BQU07a0NBQVU7Ozs7Ozs7Ozs7OzswQkFHeEIsOERBQUNGO2dCQUFJQyxXQUFVOzBCQUNiLDRFQUFDSCxtREFBS0E7b0JBQ05HLFdBQVU7b0JBQ1ZFLEtBQUk7b0JBQ0pDLE9BQU87b0JBQ1BDLFFBQVE7b0JBQ1JDLEtBQUk7Ozs7Ozs7Ozs7OzBCQUlOLDhEQUFDTjtnQkFBSUMsV0FBVTs7a0NBQ2IsOERBQUNKLGtEQUFJQTt3QkFBQ0ssTUFBTTtrQ0FBVzs7Ozs7O2tDQUN2Qiw4REFBQ0wsa0RBQUlBO3dCQUFDSyxNQUFNO3dCQUFtQkQsV0FBVTtrQ0FBK0YsNEVBQUNQLGtGQUFPQTs7Ozs7Ozs7OztrQ0FDaEosOERBQUNHLGtEQUFJQTt3QkFBQ0ssTUFBTTt3QkFBU0QsV0FBVTtrQ0FBK0YsNEVBQUNOLDJGQUFXQTs7Ozs7Ozs7OztrQ0FDMUksOERBQUNFLGtEQUFJQTt3QkFBQ0ssTUFBTTt3QkFBWUQsV0FBVTtrQ0FBK0YsNEVBQUNMLHNGQUFTQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUtuSjtBQUVBLGlFQUFlRyxNQUFNQSxFQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbWFzY3VsaW5lLy4vY29tcG9uZW50cy9OYXZiYXIuanN4PzNhYWMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBDaVNlYXJjaCB9IGZyb20gXCJyZWFjdC1pY29ucy9jaVwiO1xyXG5pbXBvcnQgeyBDaUhlYXJ0IH0gZnJvbSBcInJlYWN0LWljb25zL2NpXCI7XHJcbmltcG9ydCB7IElvQmFnSGFuZGxlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvNVwiO1xyXG5pbXBvcnQgeyBDZ1Byb2ZpbGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvY2dcIjtcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xyXG5jb25zdCBOYXZiYXIgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGZsZXgtcm93IHctMTIvMTIgZ2FwLTE2IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXItMTQgbWwtMTQgYmctWyNFREVFRjFdJz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9JyBmbGV4IGZsZXgtcm93IGdhcC04IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LXNlbWlib2xkJz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nYmctYmxhY2sgZmxleCB0ZXh0LXdoaXRlIHJvdW5kZWQtZnVsbCB3LVs0MHB4XSBoLVs0MHB4XSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14bCAnPlxyXG4gICAgICAgIDxMaW5rIGhyZWY9eycvJ30+PENpU2VhcmNoIGNsYXNzTmFtZT0nc2l6ZS02Jy8+PC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxMaW5rIGhyZWY9eycvJ30+SE9NRTwvTGluaz5cclxuICAgICAgICA8TGluayBocmVmPXsnL2NvbGxlY3Rpb25zJ30+Q09MTEVDVElPTlM8L0xpbms+XHJcbiAgICAgICAgPExpbmsgaHJlZj17Jy9kZWFscyd9PkRFQUxTPC9MaW5rPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdteS00Jz5cclxuICAgICAgICA8SW1hZ2VcclxuICAgICAgICBjbGFzc05hbWU9J2ZsZXggcm91bmRlZC14bCdcclxuICAgICAgICBzcmM9Jy9tYXNjdWxpbmUucG5nJ1xyXG4gICAgICAgIHdpZHRoPXsxNTB9XHJcbiAgICAgICAgaGVpZ2h0PXszMH1cclxuICAgICAgICBhbHQ9J2xvZ28nXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBmbGV4LXJvdyBnYXAtOCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1zZW1pYm9sZCAnPlxyXG4gICAgICAgIDxMaW5rIGhyZWY9eycvYmxvZ3MnfSA+QkxPR1M8L0xpbms+XHJcbiAgICAgICAgPExpbmsgaHJlZj17Jy9saWtlZC1wcm9kdWN0cyd9IGNsYXNzTmFtZT0nYmctYmxhY2sgZmxleCB0ZXh0LXdoaXRlIHJvdW5kZWQtZnVsbCB3LVs0MHB4XSBoLVs0MHB4XSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14bCAnPjxDaUhlYXJ0IC8+PC9MaW5rPlxyXG4gICAgICAgIDxMaW5rIGhyZWY9eycvY2FydCd9IGNsYXNzTmFtZT0nYmctYmxhY2sgZmxleCB0ZXh0LXdoaXRlIHJvdW5kZWQtZnVsbCB3LVs0MHB4XSBoLVs0MHB4XSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14bCAnPjxJb0JhZ0hhbmRsZSAvPjwvTGluaz5cclxuICAgICAgICA8TGluayBocmVmPXsnL3Byb2ZpbGUnfSBjbGFzc05hbWU9J2JnLWJsYWNrIGZsZXggdGV4dC13aGl0ZSByb3VuZGVkLWZ1bGwgdy1bNDBweF0gaC1bNDBweF0gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteGwgJz48Q2dQcm9maWxlIC8+PC9MaW5rPlxyXG5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE5hdmJhclxyXG4iXSwibmFtZXMiOlsiUmVhY3QiLCJDaVNlYXJjaCIsIkNpSGVhcnQiLCJJb0JhZ0hhbmRsZSIsIkNnUHJvZmlsZSIsIkxpbmsiLCJJbWFnZSIsIk5hdmJhciIsImRpdiIsImNsYXNzTmFtZSIsImhyZWYiLCJzcmMiLCJ3aWR0aCIsImhlaWdodCIsImFsdCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/Navbar.jsx\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_Navbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/Navbar */ \"./components/Navbar.jsx\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/Footer */ \"./components/Footer.jsx\");\n\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"bg-[#EDEEF1]\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Navbar__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\pages\\\\_app.js\",\n                lineNumber: 6,\n                columnNumber: 5\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\pages\\\\_app.js\",\n                lineNumber: 7,\n                columnNumber: 5\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Footer__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\pages\\\\_app.js\",\n                lineNumber: 8,\n                columnNumber: 5\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Work projects\\\\dapperx-ecommerce-interns\\\\pages\\\\_app.js\",\n        lineNumber: 5,\n        columnNumber: 10\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQXlDO0FBQ1g7QUFDVztBQUMxQixTQUFTRSxJQUFJLEVBQUVDLFNBQVMsRUFBRUMsU0FBUyxFQUFFO0lBQ2xELHFCQUFPLDhEQUFDQztRQUFJQyxXQUFVOzswQkFDcEIsOERBQUNOLDBEQUFNQTs7Ozs7MEJBQ1AsOERBQUNHO2dCQUFXLEdBQUdDLFNBQVM7Ozs7OzswQkFDeEIsOERBQUNILDBEQUFNQTs7Ozs7Ozs7Ozs7QUFFWCIsInNvdXJjZXMiOlsid2VicGFjazovL21hc2N1bGluZS8uL3BhZ2VzL19hcHAuanM/ZTBhZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTmF2YmFyIGZyb20gXCJAL2NvbXBvbmVudHMvTmF2YmFyXCI7XHJcbmltcG9ydCBcIkAvc3R5bGVzL2dsb2JhbHMuY3NzXCI7XHJcbmltcG9ydCBGb290ZXIgZnJvbSBcIkAvY29tcG9uZW50cy9Gb290ZXJcIjtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xyXG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjRURFRUYxXVwiPlxyXG4gICAgPE5hdmJhci8+XHJcbiAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XHJcbiAgICA8Rm9vdGVyLz5cclxuICAgIDwvZGl2PjtcclxufVxyXG4iXSwibmFtZXMiOlsiTmF2YmFyIiwiRm9vdGVyIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwiZGl2IiwiY2xhc3NOYW1lIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/react-icons"], () => (__webpack_exec__("./pages/_app.js")));
module.exports = __webpack_exports__;

})();